﻿namespace Take_Home_Week_04
{
    partial class Form1
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.cb_country = new System.Windows.Forms.ComboBox();
            this.listbox_namaplayers = new System.Windows.Forms.ListBox();
            this.lb_soccerteam = new System.Windows.Forms.Label();
            this.lb_choosecountry = new System.Windows.Forms.Label();
            this.label2 = new System.Windows.Forms.Label();
            this.cb_team = new System.Windows.Forms.ComboBox();
            this.btn_remove = new System.Windows.Forms.Button();
            this.lb_addteam = new System.Windows.Forms.Label();
            this.txtbox_teamname = new System.Windows.Forms.TextBox();
            this.lb_teamname = new System.Windows.Forms.Label();
            this.lb_teamcountry = new System.Windows.Forms.Label();
            this.txtbox_teamcountry = new System.Windows.Forms.TextBox();
            this.lb_teamcity = new System.Windows.Forms.Label();
            this.txtbox_teamcity = new System.Windows.Forms.TextBox();
            this.lb_addplayers = new System.Windows.Forms.Label();
            this.lb_playername = new System.Windows.Forms.Label();
            this.txtbox_playername = new System.Windows.Forms.TextBox();
            this.lb_number = new System.Windows.Forms.Label();
            this.txtbox_playernumber = new System.Windows.Forms.TextBox();
            this.lb_position = new System.Windows.Forms.Label();
            this.cb_position = new System.Windows.Forms.ComboBox();
            this.btn_addteam = new System.Windows.Forms.Button();
            this.btn_addplayers = new System.Windows.Forms.Button();
            this.SuspendLayout();
            // 
            // cb_country
            // 
            this.cb_country.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this.cb_country.FormattingEnabled = true;
            this.cb_country.Location = new System.Drawing.Point(152, 48);
            this.cb_country.Name = "cb_country";
            this.cb_country.Size = new System.Drawing.Size(149, 24);
            this.cb_country.TabIndex = 0;
            this.cb_country.SelectedIndexChanged += new System.EventHandler(this.cb_country_SelectedIndexChanged);
            // 
            // listbox_namaplayers
            // 
            this.listbox_namaplayers.FormattingEnabled = true;
            this.listbox_namaplayers.ItemHeight = 16;
            this.listbox_namaplayers.Location = new System.Drawing.Point(16, 144);
            this.listbox_namaplayers.Name = "listbox_namaplayers";
            this.listbox_namaplayers.Size = new System.Drawing.Size(239, 148);
            this.listbox_namaplayers.TabIndex = 1;
            // 
            // lb_soccerteam
            // 
            this.lb_soccerteam.AutoSize = true;
            this.lb_soccerteam.Font = new System.Drawing.Font("Microsoft Tai Le", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lb_soccerteam.Location = new System.Drawing.Point(12, 18);
            this.lb_soccerteam.Name = "lb_soccerteam";
            this.lb_soccerteam.Size = new System.Drawing.Size(120, 19);
            this.lb_soccerteam.TabIndex = 2;
            this.lb_soccerteam.Text = "Soccer Team List";
            // 
            // lb_choosecountry
            // 
            this.lb_choosecountry.AutoSize = true;
            this.lb_choosecountry.Font = new System.Drawing.Font("Microsoft Tai Le", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lb_choosecountry.Location = new System.Drawing.Point(12, 50);
            this.lb_choosecountry.Name = "lb_choosecountry";
            this.lb_choosecountry.Size = new System.Drawing.Size(124, 19);
            this.lb_choosecountry.TabIndex = 3;
            this.lb_choosecountry.Text = "Choose Country : ";
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Font = new System.Drawing.Font("Microsoft Tai Le", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label2.Location = new System.Drawing.Point(12, 89);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(110, 19);
            this.label2.TabIndex = 4;
            this.label2.Text = "Choose Team : ";
            // 
            // cb_team
            // 
            this.cb_team.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this.cb_team.FormattingEnabled = true;
            this.cb_team.Location = new System.Drawing.Point(152, 87);
            this.cb_team.Name = "cb_team";
            this.cb_team.Size = new System.Drawing.Size(149, 24);
            this.cb_team.TabIndex = 5;
            this.cb_team.SelectedIndexChanged += new System.EventHandler(this.cb_team_SelectedIndexChanged);
            // 
            // btn_remove
            // 
            this.btn_remove.Location = new System.Drawing.Point(16, 308);
            this.btn_remove.Name = "btn_remove";
            this.btn_remove.Size = new System.Drawing.Size(75, 23);
            this.btn_remove.TabIndex = 6;
            this.btn_remove.Text = "Remove";
            this.btn_remove.UseVisualStyleBackColor = true;
            this.btn_remove.Click += new System.EventHandler(this.btn_remove_Click);
            // 
            // lb_addteam
            // 
            this.lb_addteam.AutoSize = true;
            this.lb_addteam.Font = new System.Drawing.Font("Microsoft Tai Le", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lb_addteam.Location = new System.Drawing.Point(449, 18);
            this.lb_addteam.Name = "lb_addteam";
            this.lb_addteam.Size = new System.Drawing.Size(99, 19);
            this.lb_addteam.TabIndex = 7;
            this.lb_addteam.Text = "Adding Team";
            // 
            // txtbox_teamname
            // 
            this.txtbox_teamname.Location = new System.Drawing.Point(453, 46);
            this.txtbox_teamname.Name = "txtbox_teamname";
            this.txtbox_teamname.Size = new System.Drawing.Size(130, 22);
            this.txtbox_teamname.TabIndex = 8;
            // 
            // lb_teamname
            // 
            this.lb_teamname.AutoSize = true;
            this.lb_teamname.Font = new System.Drawing.Font("Microsoft Tai Le", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lb_teamname.Location = new System.Drawing.Point(339, 49);
            this.lb_teamname.Name = "lb_teamname";
            this.lb_teamname.Size = new System.Drawing.Size(97, 19);
            this.lb_teamname.TabIndex = 9;
            this.lb_teamname.Text = "Team Name :";
            // 
            // lb_teamcountry
            // 
            this.lb_teamcountry.AutoSize = true;
            this.lb_teamcountry.Font = new System.Drawing.Font("Microsoft Tai Le", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lb_teamcountry.Location = new System.Drawing.Point(339, 95);
            this.lb_teamcountry.Name = "lb_teamcountry";
            this.lb_teamcountry.Size = new System.Drawing.Size(108, 19);
            this.lb_teamcountry.TabIndex = 10;
            this.lb_teamcountry.Text = "Team Country :";
            // 
            // txtbox_teamcountry
            // 
            this.txtbox_teamcountry.Location = new System.Drawing.Point(453, 92);
            this.txtbox_teamcountry.Name = "txtbox_teamcountry";
            this.txtbox_teamcountry.Size = new System.Drawing.Size(130, 22);
            this.txtbox_teamcountry.TabIndex = 11;
            // 
            // lb_teamcity
            // 
            this.lb_teamcity.AutoSize = true;
            this.lb_teamcity.Font = new System.Drawing.Font("Microsoft Tai Le", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lb_teamcity.Location = new System.Drawing.Point(339, 147);
            this.lb_teamcity.Name = "lb_teamcity";
            this.lb_teamcity.Size = new System.Drawing.Size(82, 19);
            this.lb_teamcity.TabIndex = 12;
            this.lb_teamcity.Text = "Team City :";
            // 
            // txtbox_teamcity
            // 
            this.txtbox_teamcity.Location = new System.Drawing.Point(453, 144);
            this.txtbox_teamcity.Name = "txtbox_teamcity";
            this.txtbox_teamcity.Size = new System.Drawing.Size(130, 22);
            this.txtbox_teamcity.TabIndex = 13;
            // 
            // lb_addplayers
            // 
            this.lb_addplayers.AutoSize = true;
            this.lb_addplayers.Font = new System.Drawing.Font("Microsoft Tai Le", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lb_addplayers.Location = new System.Drawing.Point(769, 18);
            this.lb_addplayers.Name = "lb_addplayers";
            this.lb_addplayers.Size = new System.Drawing.Size(108, 19);
            this.lb_addplayers.TabIndex = 14;
            this.lb_addplayers.Text = "Adding Players";
            // 
            // lb_playername
            // 
            this.lb_playername.AutoSize = true;
            this.lb_playername.Font = new System.Drawing.Font("Microsoft Tai Le", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lb_playername.Location = new System.Drawing.Point(658, 47);
            this.lb_playername.Name = "lb_playername";
            this.lb_playername.Size = new System.Drawing.Size(100, 19);
            this.lb_playername.TabIndex = 15;
            this.lb_playername.Text = "Player Name :";
            // 
            // txtbox_playername
            // 
            this.txtbox_playername.Location = new System.Drawing.Point(776, 44);
            this.txtbox_playername.Name = "txtbox_playername";
            this.txtbox_playername.Size = new System.Drawing.Size(130, 22);
            this.txtbox_playername.TabIndex = 16;
            // 
            // lb_number
            // 
            this.lb_number.AutoSize = true;
            this.lb_number.Font = new System.Drawing.Font("Microsoft Tai Le", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lb_number.Location = new System.Drawing.Point(658, 92);
            this.lb_number.Name = "lb_number";
            this.lb_number.Size = new System.Drawing.Size(114, 19);
            this.lb_number.TabIndex = 17;
            this.lb_number.Text = "Player Number :";
            // 
            // txtbox_playernumber
            // 
            this.txtbox_playernumber.Location = new System.Drawing.Point(777, 90);
            this.txtbox_playernumber.Name = "txtbox_playernumber";
            this.txtbox_playernumber.Size = new System.Drawing.Size(130, 22);
            this.txtbox_playernumber.TabIndex = 18;
            // 
            // lb_position
            // 
            this.lb_position.AutoSize = true;
            this.lb_position.Font = new System.Drawing.Font("Microsoft Tai Le", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lb_position.Location = new System.Drawing.Point(658, 144);
            this.lb_position.Name = "lb_position";
            this.lb_position.Size = new System.Drawing.Size(113, 19);
            this.lb_position.TabIndex = 19;
            this.lb_position.Text = "Player Position :";
            // 
            // cb_position
            // 
            this.cb_position.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this.cb_position.FormattingEnabled = true;
            this.cb_position.Location = new System.Drawing.Point(778, 139);
            this.cb_position.Name = "cb_position";
            this.cb_position.Size = new System.Drawing.Size(130, 24);
            this.cb_position.TabIndex = 20;
            // 
            // btn_addteam
            // 
            this.btn_addteam.Location = new System.Drawing.Point(346, 197);
            this.btn_addteam.Name = "btn_addteam";
            this.btn_addteam.Size = new System.Drawing.Size(75, 23);
            this.btn_addteam.TabIndex = 21;
            this.btn_addteam.Text = "Add";
            this.btn_addteam.UseVisualStyleBackColor = true;
            this.btn_addteam.Click += new System.EventHandler(this.btn_addteam_Click);
            // 
            // btn_addplayers
            // 
            this.btn_addplayers.Location = new System.Drawing.Point(662, 197);
            this.btn_addplayers.Name = "btn_addplayers";
            this.btn_addplayers.Size = new System.Drawing.Size(75, 23);
            this.btn_addplayers.TabIndex = 22;
            this.btn_addplayers.Text = "Add";
            this.btn_addplayers.UseVisualStyleBackColor = true;
            this.btn_addplayers.Click += new System.EventHandler(this.btn_addplayers_Click);
            // 
            // Form1
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(8F, 16F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(1227, 598);
            this.Controls.Add(this.btn_addplayers);
            this.Controls.Add(this.btn_addteam);
            this.Controls.Add(this.cb_position);
            this.Controls.Add(this.lb_position);
            this.Controls.Add(this.txtbox_playernumber);
            this.Controls.Add(this.lb_number);
            this.Controls.Add(this.txtbox_playername);
            this.Controls.Add(this.lb_playername);
            this.Controls.Add(this.lb_addplayers);
            this.Controls.Add(this.txtbox_teamcity);
            this.Controls.Add(this.lb_teamcity);
            this.Controls.Add(this.txtbox_teamcountry);
            this.Controls.Add(this.lb_teamcountry);
            this.Controls.Add(this.lb_teamname);
            this.Controls.Add(this.txtbox_teamname);
            this.Controls.Add(this.lb_addteam);
            this.Controls.Add(this.btn_remove);
            this.Controls.Add(this.cb_team);
            this.Controls.Add(this.label2);
            this.Controls.Add(this.lb_choosecountry);
            this.Controls.Add(this.lb_soccerteam);
            this.Controls.Add(this.listbox_namaplayers);
            this.Controls.Add(this.cb_country);
            this.Name = "Form1";
            this.Text = "Form1";
            this.Load += new System.EventHandler(this.Form1_Load);
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion
        private System.Windows.Forms.ListBox listbox_namaplayers;
        private System.Windows.Forms.Label lb_soccerteam;
        private System.Windows.Forms.Label lb_choosecountry;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.ComboBox cb_team;
        private System.Windows.Forms.Button btn_remove;
        private System.Windows.Forms.Label lb_addteam;
        private System.Windows.Forms.TextBox txtbox_teamname;
        private System.Windows.Forms.Label lb_teamname;
        private System.Windows.Forms.Label lb_teamcountry;
        private System.Windows.Forms.TextBox txtbox_teamcountry;
        private System.Windows.Forms.Label lb_teamcity;
        private System.Windows.Forms.TextBox txtbox_teamcity;
        private System.Windows.Forms.Label lb_addplayers;
        private System.Windows.Forms.Label lb_playername;
        private System.Windows.Forms.TextBox txtbox_playername;
        private System.Windows.Forms.ComboBox cb_country;
        private System.Windows.Forms.Label lb_number;
        private System.Windows.Forms.TextBox txtbox_playernumber;
        private System.Windows.Forms.Label lb_position;
        private System.Windows.Forms.ComboBox cb_position;
        private System.Windows.Forms.Button btn_addteam;
        private System.Windows.Forms.Button btn_addplayers;
    }
}

