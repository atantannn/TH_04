﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Net.NetworkInformation;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using static Take_Home_Week_04.Form1;

namespace Take_Home_Week_04
{
    
    public partial class Form1 : Form
    {

        Team persebaya;
        Team bayernmunich;
        Team bayerleverkusen;
       
        public class Team
        {
            public string teamname;
            public string teamcountry;
            public List<Player> players;
           
            public Team (string Teamname, string Teamcountry)
            {
                teamname = Teamname;
                teamcountry = Teamcountry;
                players = new List<Player>();
            }

        }
        public class Player
        {
            public string playername;
            public string playernumber;
            public string playerposition;
            public Player(string Playername, string Playernumber, string Playerposition)
            {
                playername = Playername;
                playernumber = Playernumber;
                playerposition = Playerposition;
            }

        }
        List<Team> teamslist = new List<Team>();
        


        public Form1()
        {
            InitializeComponent();
            cb_position.Items.Add("GK");
            cb_position.Items.Add("DF");
            cb_position.Items.Add("MF");
            cb_position.Items.Add("FW");
            cb_country.Items.Add("Indonesia");

        }
        


        private void btn_remove_Click(object sender, EventArgs e)
        {
            string selectedteam = cb_team.Text;
            Team teamyangdipilih = null;
            string pemainyangdipilih = listbox_namaplayers.SelectedItem.ToString();

            // Memisahkan string
            string[] playerInfoParts = pemainyangdipilih.Split(new char[] { '(', ')' }, StringSplitOptions.RemoveEmptyEntries);

            string playerNumber = playerInfoParts[0].Trim(); // Nomor pemain berada di indeks 0 setelah pemisahan

            if (listbox_namaplayers.Items.Count <= 11)
            {
                MessageBox.Show("Unable to Remove Players if Players less than equal 11", "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
            else
            {
                foreach (Team team in teamslist)
                {
                    if (team.teamname == selectedteam)
                    {
                        teamyangdipilih = team;
                            for (int i = 0; i < teamyangdipilih.players.Count; i++)
                            {
                                if (team.players[i].playernumber == playerNumber)
                                {
                                    teamyangdipilih.players.RemoveAt(i);
                                    listbox_namaplayers.Items.Remove(pemainyangdipilih);
                                break;
                                }

                            }
                        
                    }
                    break;
                }
                
            }

            

        }

        private void btn_addteam_Click(object sender, EventArgs e)
        {
            

            if (string.IsNullOrEmpty(txtbox_teamname.Text) || string.IsNullOrEmpty(txtbox_teamcountry.Text) || string.IsNullOrEmpty(txtbox_teamcity.Text))
            {
                MessageBox.Show("All Fields Need to be Filled", "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
            else
            {
                
                for (int i = 0; i < teamslist.Count; i++)
                {
                    if (teamslist[i].teamname == txtbox_teamname.Text)
                    {
                        MessageBox.Show("Team Sudah Ada", "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
                        return;

                    }

                }
               

                Team teambaru = new Team(txtbox_teamname.Text, txtbox_teamcountry.Text);
                teamslist.Add(teambaru);
                
                
                foreach (string country in cb_country.Items)
                {
                    if (country == txtbox_teamcountry.Text)
                    {
                        break;
                    }
                    else
                    {
                        cb_country.Items.Add(txtbox_teamcountry.Text);
                    }
                }
                cb_team.Items.Add(txtbox_teamname.Text);


                txtbox_teamname.Clear();
                txtbox_teamcountry.Clear();
                txtbox_teamcity.Clear();
            }
        }
            
        

        private void cb_country_SelectedIndexChanged(object sender, EventArgs e)
        {
            cb_team.Items.Clear();
            string selectedcountry = cb_country.Text;
            foreach (Team team in teamslist)
            {
                if (team.teamcountry == selectedcountry)
                {
                    cb_team.Items.Add(team.teamname);
                }
            }
            listbox_namaplayers.Items.Clear();
        }

        private void btn_addplayers_Click(object sender, EventArgs e)
        {
            string selectedteam = cb_team.Text;

            if (string.IsNullOrEmpty(txtbox_playername.Text) || string.IsNullOrEmpty(txtbox_playernumber.Text) || string.IsNullOrEmpty(cb_position.Text))
            {
                MessageBox.Show("All Fields Need to be Filled", "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
            else
            {
                string selectedTeamName = cb_team.Text;
                Team selectedTeam = null;

                
                for (int i = 0; i < teamslist.Count; i++)
                {
                    if (teamslist[i].teamname == selectedTeamName)
                    {
                        selectedTeam = teamslist[i];
                        break;
                    }
                }

                if (selectedTeam != null)
                {
                    foreach (Player player in selectedTeam.players)
                    {
                        if (player.playernumber == txtbox_playernumber.Text)
                        {
                            MessageBox.Show("Player with Same Number is Found in the Team", "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
                            return;
                        }
                    }

                    Player playerbaru = new Player(txtbox_playername.Text, txtbox_playernumber.Text, cb_position.SelectedItem.ToString());
                    selectedTeam.players.Add(playerbaru);
                    listbox_namaplayers.Items.Add($"({txtbox_playernumber.Text}) {txtbox_playername.Text}, {cb_position.Text}");
                }
                txtbox_playername.Clear();
                txtbox_playernumber.Clear();
                
                
                //Player playerbaru = new Player(txtbox_playernumber.Text, txtbox_playername.Text, cb_position.SelectedItem.ToString());
                //listbox_namaplayers.Items.Add($"({txtbox_playernumber.Text}) {txtbox_playername.Text} , {cb_position.Text}");

            }
        }

        private void cb_team_SelectedIndexChanged(object sender, EventArgs e)
        {

            listbox_namaplayers.Items.Clear();
            string selectedteam = cb_team.Text;
            
            foreach (Team team in teamslist)
            {
                if (team.teamname == selectedteam)
                {
                    foreach (Player player in team.players)
                    {
                        listbox_namaplayers.Items.Add($"({player.playernumber}) {player.playername}, {player.playerposition}");
                    }
                }
            }



        }

        private void Form1_Load(object sender, EventArgs e)
        {
            persebaya = new Team("Persebaya", "Indonesia");
            teamslist.Add(persebaya);
            persebaya.players.Add(new Player("Lalu Muhammad Rizki", "01", "GK"));
            persebaya.players.Add(new Player("Arief Catur", "02", "DF"));
            persebaya.players.Add(new Player("Andre Oktaviansyah", "08", "MF"));
            persebaya.players.Add(new Player("Mikael Alfredo Tata", "25", "DF"));
            persebaya.players.Add(new Player("Muhammad Iqbal", "06", "FW"));
            persebaya.players.Add(new Player("Aditya Arya", "64", "GK"));
            persebaya.players.Add(new Player("Roy Ivansyah", "17", "DF"));
            persebaya.players.Add(new Player("Alfan Suaib", "28", "MF"));
            persebaya.players.Add(new Player("Robson Duarte", "30", "FW"));
            persebaya.players.Add(new Player("Paulo Hnerique", "9", "FW"));
            persebaya.players.Add(new Player("Ripal Wahyudi", "36", "MF"));

            cb_country.Items.Add("Germany");
            bayernmunich = new Team("Bayern Munich", "Germany");
            teamslist.Add(bayernmunich);
            bayernmunich.players.Add(new Player("Daniel Peretz", "18", "GK"));
            bayernmunich.players.Add(new Player("Manuel Neuer", "01", "GK"));
            bayernmunich.players.Add(new Player("Eric Dier", "15", "MF"));
            bayernmunich.players.Add(new Player("Matthijs de Ligt", "04", "DF"));
            bayernmunich.players.Add(new Player("Benjamin Pavard", "05", "DF"));
            bayernmunich.players.Add(new Player("Serge Gnarby", "07", "FW"));
            bayernmunich.players.Add(new Player("Paul Wanner", "14", "MF"));
            bayernmunich.players.Add(new Player("Sven Ulreich", "26", "GK"));
            bayernmunich.players.Add(new Player("Lucas Hemandez", "21", "DF"));
            bayernmunich.players.Add(new Player("Joshua Kimmich", "06", "MF"));
            bayernmunich.players.Add(new Player("Leon Goretzka", "08", "MF"));


            bayerleverkusen = new Team("Bayer Leverkusen", "Germany");
            teamslist.Add(bayerleverkusen);
            bayerleverkusen.players.Add(new Player("Lukas Hradekcy", "01", "GK"));
            bayerleverkusen.players.Add(new Player("Josip Stanistic", "02", "DF"));
            bayerleverkusen.players.Add(new Player("Piero Hincapie", "03", "DF"));
            bayerleverkusen.players.Add(new Player("Jonathan Tah", "04", "DF"));
            bayerleverkusen.players.Add(new Player("Odilon Kossounou", "06", "DF"));
            bayerleverkusen.players.Add(new Player("Robert Andrich", "08", "MF"));
            bayerleverkusen.players.Add(new Player("Florian Wirtz", "10", "MF"));
            bayerleverkusen.players.Add(new Player("Patrik Schick", "13", "FW"));
            bayerleverkusen.players.Add(new Player("Matej Kovar", "17", "GK"));
            bayerleverkusen.players.Add(new Player("Nathan Tella", "19", "FW"));
            bayerleverkusen.players.Add(new Player("Niklas Lomb", "36", "GK"));
            



        }




            


            
            
           
            
          
           
        }
    }

